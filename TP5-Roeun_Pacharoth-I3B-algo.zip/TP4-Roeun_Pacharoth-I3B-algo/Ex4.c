#include<stdio.h>
int main() {
    int p,i;

    for(i=1;i<=100;i++){
        
        if (i%3==0&&i!=30&&i!=60&&i!=90)
        {
            /* code */
            printf(" %d",i);
            
        }
        
        
    }
    return 0;
}