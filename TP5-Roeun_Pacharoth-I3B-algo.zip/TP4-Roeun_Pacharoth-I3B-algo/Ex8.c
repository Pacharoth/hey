#include<stdio.h>
int main(){
    int i;
    for(i=0;i<=30;i+=2){
        printf("%d ",i);
    }
}