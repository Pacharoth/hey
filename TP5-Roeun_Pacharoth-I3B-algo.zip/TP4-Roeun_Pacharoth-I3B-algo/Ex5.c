#include <stdio.h>
int main(){
    int count=0;
    for (int i = 1; i <= 100; i++)
    {
        count+=i;
        /* code */
    }
    printf("The result is %d",count);
    
}