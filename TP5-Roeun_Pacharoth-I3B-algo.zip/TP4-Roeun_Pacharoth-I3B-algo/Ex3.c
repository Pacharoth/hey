#include<stdio.h>
int main() {
    int i;
    for(i=8;i<=1000;i++){
        i+=1;
        if (i!=50&&i!=11&&i!=17&&i!=21)
        {
            /* code */
            printf(" %d",i);
            
        }
        
        
    }
    return 0;
}