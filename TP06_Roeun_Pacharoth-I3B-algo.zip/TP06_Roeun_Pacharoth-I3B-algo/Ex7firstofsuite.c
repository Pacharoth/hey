#include <stdio.h>
int main(){
    int n=0,i,fabona,a=1,b=0;
    printf("Enter number positive:");
    scanf("%d",&n);
    for (i=0;i<n;++i){
        printf("%d ",fabona);
        fabona = b +a;
        a = b;
        b = fabona;
    
    }
    
    
}